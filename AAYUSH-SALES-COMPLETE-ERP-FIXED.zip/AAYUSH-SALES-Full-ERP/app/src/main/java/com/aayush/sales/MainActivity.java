
package com.aayush.sales;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.print.*;
import android.view.*;
import android.widget.*;
import android.database.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout body; int primary=Color.rgb(22,78,99);
    ArrayList<Line> cart=new ArrayList<>();
    TextView header;

    static class Line {
        long productId; String name; double qty, rate;
        Line(long p,String n,double q,double r){productId=p;name=n;qty=q;rate=r;}
        double amount(){return qty*rate;}
    }

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);dashboard();}

    TextView text(String s,float size){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.DKGRAY);t.setPadding(16,12,16,12);return t;
    }
    EditText edit(String hint){
        EditText e=new EditText(this);e.setHint(hint);e.setPadding(16,10,16,10);return e;
    }
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    void screen(String title){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(243,247,249));
        header=text("AAYUSH SALES\n"+title,21);header.setTextColor(Color.WHITE);header.setBackgroundColor(primary);
        root.addView(header,new LinearLayout.LayoutParams(-1,84));
        ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(8,8,8,24);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void addNav(String label, final Runnable r){Button b=button(label);b.setOnClickListener(v->r.run());body.addView(b);}
    void dashboard(){
        screen("Retail ERP Dashboard");
        double sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales");
        double purchase=db.scalar("SELECT COALESCE(SUM(total),0) FROM purchases");
        double expense=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");
        body.addView(text("Today / Overall Summary\nSales: ₹"+sales+"\nPurchases: ₹"+purchase+"\nExpenses: ₹"+expense,18));
        addNav("🧾  New Sale / Invoice",()->newSale());
        addNav("📋  Sales & Invoice History",()->salesHistory());
        addNav("📦  Products / Stock",()->products());
        addNav("👥  Customers / Ledger",()->customers());
        addNav("🚚  Purchase Entry",()->purchase());
        addNav("💸  Expenses",()->expenses());
        addNav("📊  Reports",()->reports());
        addNav("⚙  Shop / Invoice Settings",()->settings());
        body.addView(text("\nAAYUSH SALES\nOffline retail ERP • Data stored locally on the phone\nInvoice: Print • PDF • Image",15));
    }

    void newSale(){
        cart.clear();screen("New Sale / Invoice");
        EditText customer=edit("Customer name (optional)");body.addView(customer);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        EditText item=edit("Product / Item"); EditText qty=edit("Qty"); EditText rate=edit("Rate");
        row.addView(item,new LinearLayout.LayoutParams(0,-2,2));row.addView(qty,new LinearLayout.LayoutParams(0,-2,1));row.addView(rate,new LinearLayout.LayoutParams(0,-2,1));body.addView(row);
        Button add=button("＋ Add Item");body.addView(add);
        TextView cartText=text("No items added",16);body.addView(cartText);
        EditText discount=edit("Discount");EditText paid=edit("Paid");body.addView(discount);body.addView(paid);
        TextView total=text("Total: ₹0.00",19);body.addView(total);
        add.setOnClickListener(v->{
            try{double q=Double.parseDouble(qty.getText().toString());double r=Double.parseDouble(rate.getText().toString());
                cart.add(new Line(0,item.getText().toString(),q,r)); StringBuilder x=new StringBuilder();
                double sum=0; for(Line l:cart){x.append(l.name+"  "+l.qty+" × ₹"+l.rate+" = ₹"+l.amount()+"\n");sum+=l.amount();}
                cartText.setText(x.toString());total.setText("Total: ₹"+sum);
                item.setText("");qty.setText("");rate.setText("");
            }catch(Exception e){Toast.makeText(this,"Enter item, qty and rate",0).show();}
        });
        Button save=button("💾 Save Invoice");body.addView(save);
        save.setOnClickListener(v->{
            if(cart.isEmpty()){Toast.makeText(this,"Add at least one item",0).show();return;}
            double sub=0;for(Line l:cart)sub+=l.amount();
            double dis=parse(discount),pay=parse(paid),tot=Math.max(0,sub-dis),bal=Math.max(0,tot-pay);
            String inv="INV-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.getDefault()).format(new Date());
            long id=db.createCashSale(inv,customer.getText().toString().trim().isEmpty()?"Cash Customer":customer.getText().toString().trim(),System.currentTimeMillis(),sub,dis,pay,tot,bal);
            for(Line l:cart)db.addSaleItem(id,l.productId,l.name,l.qty,l.rate);
            Toast.makeText(this,inv+" saved",Toast.LENGTH_LONG).show();
            showInvoiceActions(id);
        });
    }
    double parse(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}

    void products(){
        screen("Products / Stock");
        EditText name=edit("Product name");EditText sku=edit("SKU / Code");EditText unit=edit("Unit (pcs, bag, kg...)");
        EditText purchase=edit("Purchase rate");EditText sale=edit("Sale rate");EditText stock=edit("Opening stock");
        body.addView(name);body.addView(sku);body.addView(unit);body.addView(purchase);body.addView(sale);body.addView(stock);
        Button add=button("＋ Add Product");body.addView(add);
        add.setOnClickListener(v->{try{db.addProduct(name.getText().toString(),sku.getText().toString(),unit.getText().toString(),Double.parseDouble(purchase.getText().toString()),Double.parseDouble(sale.getText().toString()),Double.parseDouble(stock.getText().toString()));Toast.makeText(this,"Product saved",0).show();products();}catch(Exception e){Toast.makeText(this,"Fill product details",0).show();}});
        Cursor c=db.products();StringBuilder s=new StringBuilder("\nSTOCK LIST\n");
        while(c.moveToNext())s.append("\n").append(c.getString(1)).append(" | Stock: ").append(c.getDouble(6)).append(" | Sale: ₹").append(c.getDouble(5));
        c.close();body.addView(text(s.toString(),16));
    }

    void customers(){
        screen("Customers / Ledger");
        EditText name=edit("Customer name");EditText phone=edit("Phone");EditText address=edit("Address");
        body.addView(name);body.addView(phone);body.addView(address);
        Button add=button("＋ Add Customer");body.addView(add);
        add.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty())return;db.addCustomer(name.getText().toString(),phone.getText().toString(),address.getText().toString());Toast.makeText(this,"Customer saved",0).show();customers();});
        Cursor c=db.customers();StringBuilder s=new StringBuilder("\nCUSTOMERS\n");
        while(c.moveToNext())s.append("\n").append(c.getString(1)).append(" • ").append(c.getString(2));
        c.close();body.addView(text(s.toString(),16));
    }

    void purchase(){
        screen("Purchase Entry");
        EditText bill=edit("Bill number");EditText supplier=edit("Supplier");EditText item=edit("Product");EditText qty=edit("Qty");EditText rate=edit("Rate");EditText paid=edit("Paid");
        body.addView(bill);body.addView(supplier);body.addView(item);body.addView(qty);body.addView(rate);body.addView(paid);
        Button save=button("💾 Save Purchase");body.addView(save);
        save.setOnClickListener(v->{try{double q=Double.parseDouble(qty.getText().toString()),r=Double.parseDouble(rate.getText().toString()),p=parse(paid),t=q*r,b=Math.max(0,t-p);
            long id=db.createPurchase(bill.getText().toString(),supplier.getText().toString(),System.currentTimeMillis(),t,p,b);db.addPurchaseItem(id,0,item.getText().toString(),q,r);Toast.makeText(this,"Purchase saved",0).show();}catch(Exception e){Toast.makeText(this,"Fill purchase details",0).show();}});
        Cursor c=db.purchases();StringBuilder s=new StringBuilder("\nPURCHASE HISTORY\n");while(c.moveToNext())s.append("\n").append(c.getString(1)).append(" • ").append(c.getString(2)).append(" • ₹").append(c.getDouble(4));c.close();body.addView(text(s.toString(),16));
    }

    void expenses(){
        screen("Expenses");
        EditText title=edit("Expense title");EditText amount=edit("Amount");EditText note=edit("Note");
        body.addView(title);body.addView(amount);body.addView(note);
        Button add=button("＋ Save Expense");body.addView(add);
        add.setOnClickListener(v->{try{db.addExpense(title.getText().toString(),Double.parseDouble(amount.getText().toString()),note.getText().toString());Toast.makeText(this,"Expense saved",0).show();expenses();}catch(Exception e){Toast.makeText(this,"Enter valid amount",0).show();}});
        Cursor c=db.expenses();StringBuilder s=new StringBuilder("\nEXPENSE HISTORY\n");while(c.moveToNext())s.append("\n").append(c.getString(1)).append(" • ₹").append(c.getDouble(2));c.close();body.addView(text(s.toString(),16));
    }

    void salesHistory(){
        screen("Sales & Invoice History");Cursor c=db.sales();
        while(c.moveToNext()){
            final long id=c.getLong(0);String s=c.getString(1)+"\n"+c.getString(3)+"\nTotal ₹"+c.getDouble(8)+" • Paid ₹"+c.getDouble(7)+" • Balance ₹"+c.getDouble(9);
            body.addView(text(s,16));Button b=button("🖨  Print / PDF / Image");b.setOnClickListener(v->showInvoiceActions(id));body.addView(b);
        }c.close();
    }

    void reports(){
        screen("Reports");
        double sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales");
        double paid=db.scalar("SELECT COALESCE(SUM(paid),0) FROM sales");
        double due=db.scalar("SELECT COALESCE(SUM(balance),0) FROM sales");
        double purchases=db.scalar("SELECT COALESCE(SUM(total),0) FROM purchases");
        double expenses=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");
        body.addView(text("SALES REPORT\n\nTotal Sales: ₹"+sales+"\nCollected: ₹"+paid+"\nCustomer Due: ₹"+due+"\n\nPURCHASES: ₹"+purchases+"\nEXPENSES: ₹"+expenses+"\n\nGross Sales − Purchases − Expenses: ₹"+(sales-purchases-expenses),20));
    }

    void settings(){
        screen("Shop / Invoice Settings");
        EditText n=edit("Shop name");EditText a=edit("Shop address");EditText p=edit("Phone");EditText g=edit("GSTIN");
        n.setText(db.setting("shop_name"));a.setText(db.setting("shop_address"));p.setText(db.setting("shop_phone"));g.setText(db.setting("gstin"));
        body.addView(n);body.addView(a);body.addView(p);body.addView(g);
        Button save=button("💾 Save Settings");body.addView(save);
        save.setOnClickListener(v->{db.setting("shop_name",n.getText().toString());db.setting("shop_address",a.getText().toString());db.setting("shop_phone",p.getText().toString());db.setting("gstin",g.getText().toString());Toast.makeText(this,"Settings saved",0).show();});
        body.addView(text("\nBackup / Restore can be added as the next secure module without changing sales data.",15));
    }

    void showInvoiceActions(long id){
        new AlertDialog.Builder(this).setTitle("Invoice")
            .setItems(new String[]{"🖨 Print","📄 Save PDF","🖼 Save Image"},(d,w)->{
                if(w==0)printInvoice(id);else if(w==1)savePdf(id);else saveImage(id);
            }).show();
    }

    Bitmap invoiceBitmap(long id){
        Cursor s=db.sale(id);if(!s.moveToFirst()){s.close();return null;}
        String inv=s.getString(1),customer=s.getString(3);double sub=s.getDouble(5),dis=s.getDouble(6),paid=s.getDouble(7),total=s.getDouble(8),bal=s.getDouble(9);
        Bitmap b=Bitmap.createBitmap(1000,1400,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(Color.WHITE);
        Paint p=new Paint(1);p.setColor(Color.BLACK);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(48);c.drawText(db.setting("shop_name"),50,70,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(26);c.drawText(db.setting("shop_address"),50,110,p);c.drawText("Phone: "+db.setting("shop_phone"),50,145,p);
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(34);c.drawText("TAX / RETAIL INVOICE",50,205,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(25);c.drawText(inv,50,245,p);c.drawText("Date: "+new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date(s.getLong(4))),50,280,p);
        c.drawText("Customer: "+customer,50,330,p);
        p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Item",50,400,p);c.drawText("Qty",560,400,p);c.drawText("Rate",690,400,p);c.drawText("Amount",830,400,p);
        Cursor it=db.saleItems(id);int y=450;while(it.moveToNext()){p.setTypeface(Typeface.DEFAULT);c.drawText(it.getString(3),50,y,p);c.drawText(""+it.getDouble(4),560,y,p);c.drawText("₹"+it.getDouble(5),690,y,p);c.drawText("₹"+it.getDouble(6),830,y,p);y+=50;}it.close();
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(30);c.drawText("Subtotal: ₹"+sub,50,y+60,p);c.drawText("Discount: ₹"+dis,50,y+105,p);c.drawText("TOTAL: ₹"+total,50,y+160,p);c.drawText("Paid: ₹"+paid,50,y+205,p);c.drawText("BALANCE: ₹"+bal,50,y+250,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(24);c.drawText("Thank you for your business.",50,y+330,p);s.close();return b;
    }

    void savePdf(long id){
        Bitmap b=invoiceBitmap(id);if(b==null)return;PdfDocument doc=new PdfDocument();PdfDocument.Page pg=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
        pg.getCanvas().drawBitmap(b,null,new Rect(20,20,575,820),new Paint(1));doc.finishPage(pg);
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,"AAYUSH-SALES-"+id+".pdf");pendingDoc=doc;startActivityForResult(i,501);
    }
    PdfDocument pendingDoc;Bitmap pendingImage;
    void saveImage(long id){pendingImage=invoiceBitmap(id);Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("image/png");i.putExtra(Intent.EXTRA_TITLE,"AAYUSH-SALES-"+id+".png");startActivityForResult(i,502);}
    void printInvoice(long id){
        final Bitmap b=invoiceBitmap(id);if(b==null)return;PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        pm.print("AAYUSH SALES Invoice",new PrintDocumentAdapter(){
            public void onLayout(PrintAttributes a,PrintAttributes b,android.os.CancellationSignal c,LayoutResultCallback cb,Bundle x){cb.onLayoutFinished(new PrintDocumentInfo.Builder("invoice.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(),true);}
            public void onWrite(PageRange[] r,android.os.ParcelFileDescriptor fd,android.os.CancellationSignal c,WriteResultCallback cb){try{PdfDocument d=new PdfDocument();PdfDocument.Page pg=d.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());pg.getCanvas().drawBitmap(b,null,new Rect(20,20,575,820),new Paint(1));d.finishPage(pg);d.writeTo(new FileOutputStream(fd.getFileDescriptor()));d.close();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.toString());}}
        },null);
    }

    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data);if(c!=RESULT_OK||data==null)return;
        try(OutputStream o=getContentResolver().openOutputStream(data.getData())){
            if(r==501&&pendingDoc!=null){pendingDoc.writeTo(o);pendingDoc.close();pendingDoc=null;Toast.makeText(this,"PDF saved",0).show();}
            else if(r==502&&pendingImage!=null){pendingImage.compress(Bitmap.CompressFormat.PNG,100,o);pendingImage=null;Toast.makeText(this,"Image saved",0).show();}
        }catch(Exception e){Toast.makeText(this,"Save failed: "+e.getMessage(),1).show();}
    }
}
