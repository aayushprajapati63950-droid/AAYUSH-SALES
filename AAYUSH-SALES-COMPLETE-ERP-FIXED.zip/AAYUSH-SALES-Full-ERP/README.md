# AAYUSH SALES — Complete Fresh Retail ERP

AAYUSH SALES has been rebuilt from scratch as a standalone Android retail ERP project.

## Included in one build
- Dashboard
- Sales / New Invoice
- Multiple invoice line items
- Automatic invoice number
- Customer name
- Discount, paid and balance
- Invoice history
- Print invoice
- Save invoice as PDF
- Save invoice as PNG image
- Products / Stock
- Opening stock
- Stock decreases on sale
- Purchase entry
- Stock increases on purchase
- Customers
- Expenses
- Sales / Purchase / Expense reports
- Shop name, address, phone and GSTIN settings
- Offline SQLite database
- No internet required for normal data entry

## Build
Open this project in Android Studio or another compatible Android Gradle IDE, sync Gradle, then:
Build → Build APK(s)

This chat environment does not have Android SDK/Gradle build tools installed, so the APK itself is not falsely claimed as compiled here.
