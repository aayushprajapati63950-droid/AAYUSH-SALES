
package com.aayush.sales;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.util.*;

public class DB extends SQLiteOpenHelper {
    public DB(Context c) { super(c, "aayush_sales.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, sku TEXT, unit TEXT, purchase REAL DEFAULT 0, sale REAL DEFAULT 0, stock REAL DEFAULT 0)");
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT, balance REAL DEFAULT 0)");
        d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT, customer_id INTEGER, customer_name TEXT, date INTEGER, subtotal REAL, discount REAL, paid REAL, total REAL, balance REAL)");
        d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER, product_id INTEGER, product_name TEXT, qty REAL, rate REAL, amount REAL)");
        d.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT, bill_no TEXT, supplier TEXT, date INTEGER, total REAL, paid REAL, balance REAL)");
        d.execSQL("CREATE TABLE purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER, product_id INTEGER, product_name TEXT, qty REAL, rate REAL, amount REAL)");
        d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount REAL, date INTEGER, note TEXT)");
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT)");
        d.execSQL("INSERT INTO settings(k,v) VALUES('shop_name','AAYUSH SALES')");
        d.execSQL("INSERT INTO settings(k,v) VALUES('shop_address','')");
        d.execSQL("INSERT INTO settings(k,v) VALUES('shop_phone','')");
        d.execSQL("INSERT INTO settings(k,v) VALUES('gstin','')");
    }

    @Override public void onUpgrade(SQLiteDatabase d, int oldV, int newV) {}

    public long addProduct(String name,String sku,String unit,double purchase,double sale,double stock) {
        ContentValues v=new ContentValues();
        v.put("name",name); v.put("sku",sku); v.put("unit",unit);
        v.put("purchase",purchase); v.put("sale",sale); v.put("stock",stock);
        return getWritableDatabase().insert("products",null,v);
    }
    public long addCustomer(String name,String phone,String address) {
        ContentValues v=new ContentValues();
        v.put("name",name); v.put("phone",phone); v.put("address",address);
        return getWritableDatabase().insert("customers",null,v);
    }
    public long addExpense(String title,double amount,String note) {
        ContentValues v=new ContentValues();
        v.put("title",title); v.put("amount",amount); v.put("date",System.currentTimeMillis()); v.put("note",note);
        return getWritableDatabase().insert("expenses",null,v);
    }
    public long createSale(String invoice,String customer,long date,double subtotal,double discount,double paid,double total,double balance) {
        ContentValues v=new ContentValues();
        v.put("invoice_no",invoice); v.put("customer_id",customer); v.put("customer_name",getCustomerName(customer));
        v.put("date",date); v.put("subtotal",subtotal); v.put("discount",discount); v.put("paid",paid); v.put("total",total); v.put("balance",balance);
        return getWritableDatabase().insert("sales",null,v);
    }
    public String getCustomerName(long id) {
        Cursor c=getReadableDatabase().rawQuery("SELECT name FROM customers WHERE id=?",new String[]{""+id});
        String s="Cash Customer"; if(c.moveToFirst()) s=c.getString(0); c.close(); return s;
    }
    public long createCashSale(String invoice,String customerName,long date,double subtotal,double discount,double paid,double total,double balance) {
        ContentValues v=new ContentValues();
        v.put("invoice_no",invoice); v.put("customer_id",0); v.put("customer_name",customerName);
        v.put("date",date); v.put("subtotal",subtotal); v.put("discount",discount); v.put("paid",paid); v.put("total",total); v.put("balance",balance);
        return getWritableDatabase().insert("sales",null,v);
    }
    public void addSaleItem(long saleId,long productId,String productName,double qty,double rate) {
        ContentValues v=new ContentValues();
        v.put("sale_id",saleId); v.put("product_id",productId); v.put("product_name",productName);
        v.put("qty",qty); v.put("rate",rate); v.put("amount",qty*rate);
        getWritableDatabase().insert("sale_items",null,v);
        if(productId>0) getWritableDatabase().execSQL("UPDATE products SET stock=stock-? WHERE id=?",new Object[]{qty,productId});
    }
    public long createPurchase(String bill,String supplier,long date,double total,double paid,double balance) {
        ContentValues v=new ContentValues();
        v.put("bill_no",bill); v.put("supplier",supplier); v.put("date",date); v.put("total",total); v.put("paid",paid); v.put("balance",balance);
        return getWritableDatabase().insert("purchases",null,v);
    }
    public void addPurchaseItem(long purchaseId,long productId,String name,double qty,double rate) {
        ContentValues v=new ContentValues();
        v.put("purchase_id",purchaseId); v.put("product_id",productId); v.put("product_name",name);
        v.put("qty",qty); v.put("rate",rate); v.put("amount",qty*rate);
        getWritableDatabase().insert("purchase_items",null,v);
        if(productId>0) getWritableDatabase().execSQL("UPDATE products SET stock=stock+?, purchase=? WHERE id=?",new Object[]{qty,rate,productId});
    }
    public Cursor products(){return getReadableDatabase().query("products",null,null,null,null,null,"name ASC");}
    public Cursor customers(){return getReadableDatabase().query("customers",null,null,null,null,null,"name ASC");}
    public Cursor sales(){return getReadableDatabase().query("sales",null,null,null,null,null,"id DESC");}
    public Cursor purchases(){return getReadableDatabase().query("purchases",null,null,null,null,null,"id DESC");}
    public Cursor expenses(){return getReadableDatabase().query("expenses",null,null,null,null,null,"id DESC");}
    public Cursor sale(long id){return getReadableDatabase().query("sales",null,"id=?",new String[]{""+id},null,null,null);}
    public Cursor saleItems(long id){return getReadableDatabase().query("sale_items",null,"sale_id=?",new String[]{""+id},null,null,"id ASC");}

    public double scalar(String sql) {
        Cursor c=getReadableDatabase().rawQuery(sql,null); double x=0; if(c.moveToFirst()) x=c.getDouble(0); c.close(); return x;
    }
    public String setting(String k) {
        Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});
        String s=""; if(c.moveToFirst()) s=c.getString(0); c.close(); return s;
    }
    public void setting(String k,String v) {
        ContentValues x=new ContentValues(); x.put("k",k);x.put("v",v);
        getWritableDatabase().insertWithOnConflict("settings",null,x,SQLiteDatabase.CONFLICT_REPLACE);
    }
}
