package com.aayush.sales;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.print.*;
import android.view.*;
import android.widget.*;
import android.database.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout body; final int navy=Color.rgb(20,55,75), teal=Color.rgb(20,140,125), bg=Color.rgb(246,248,250), white=Color.WHITE;
    ArrayList<Line> cart=new ArrayList<>(); String currentScreen="HOME";
    static class Line { long productId; String name,unit; double qty,rate; Line(long p,String n,String u,double q,double r){productId=p;name=n;unit=u;qty=q;rate=r;} double amount(){return qty*rate;} }

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);home();}
    TextView tv(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(Color.rgb(45,55,60));t.setPadding(16,10,16,10);return t;}
    EditText ed(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine(true);e.setPadding(14,5,14,5);return e;}
    GradientDrawable shape(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    Button btn(String s,int color){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(color==white?navy:white);b.setAllCaps(false);b.setBackground(shape(color,18));b.setPadding(10,2,10,2);return b;}
    TextView label(String s){TextView t=tv(s,12);t.setTextColor(Color.GRAY);t.setPadding(4,12,4,2);return t;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(14,12,14,12);l.setBackground(shape(white,22));l.setElevation(2);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,7,0,7);l.setLayoutParams(p);return l;}
    void base(String title){
        currentScreen=title; LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(16,6,10,4);top.setBackgroundColor(white);
        TextView back=tv("‹",34);back.setTextColor(navy);back.setGravity(Gravity.CENTER);top.addView(back,new LinearLayout.LayoutParams(48,58));
        LinearLayout tt=new LinearLayout(this);tt.setOrientation(LinearLayout.VERTICAL);TextView a=tv("AAYUSH SALES",19);a.setTypeface(Typeface.DEFAULT_BOLD);a.setTextColor(navy);TextView sub=tv(title,12);sub.setTextColor(Color.GRAY);tt.addView(a);tt.addView(sub);top.addView(tt,new LinearLayout.LayoutParams(0,58,1));
        TextView more=tv("⋮",30);more.setGravity(Gravity.CENTER);top.addView(more,new LinearLayout.LayoutParams(42,58));
        back.setOnClickListener(v->{if("HOME".equals(currentScreen))superBack();else home();});
        root.addView(top,new LinearLayout.LayoutParams(-1,64));
        ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(12,8,12,90);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setPadding(8,4,8,4);nav.setBackgroundColor(white);
        nav.addView(navBtn("⌂\nHOME",()->home()),new LinearLayout.LayoutParams(0,64,1));nav.addView(navBtn("▦\nDASHBOARD",()->dashboard()),new LinearLayout.LayoutParams(0,64,1));nav.addView(navBtn("▤\nITEMS",()->products()),new LinearLayout.LayoutParams(0,64,1));nav.addView(navBtn("☰\nMENU",()->menu()),new LinearLayout.LayoutParams(0,64,1));
        root.addView(nav,new LinearLayout.LayoutParams(-1,72));setContentView(root);
    }
    Button navBtn(String s,final Runnable r){Button b=btn(s,white);b.setTextColor(Color.DKGRAY);b.setTextSize(11);b.setOnClickListener(v->r.run());return b;}
    void superBack(){super.onBackPressed();}
    @Override public void onBackPressed(){if(!"HOME".equals(currentScreen))home();else superBack();}

    void home(){base("HOME");
        LinearLayout search=card(); TextView q=tv("⌕  Search customer, invoice or item",15);q.setTextColor(Color.GRAY);search.addView(q);body.addView(search);
        LinearLayout quick=card();TextView h=tv("Quick Links",17);h.setTypeface(Typeface.DEFAULT_BOLD);quick.addView(h);
        LinearLayout r=new LinearLayout(this);String[] qs={"▣ Online Store","▤ Stock Summary","⚙ Item Settings","Show All"};for(String x:qs){TextView t=tv(x,12);t.setGravity(Gravity.CENTER);t.setTextColor(teal);r.addView(t,new LinearLayout.LayoutParams(0,62,1));}quick.addView(r);body.addView(quick);
        LinearLayout stats=card();TextView sh=tv("Today's Business",17);sh.setTypeface(Typeface.DEFAULT_BOLD);stats.addView(sh);LinearLayout sr=new LinearLayout(this);double sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales");double due=db.scalar("SELECT COALESCE(SUM(balance),0) FROM sales");sr.addView(stat("Sales","₹"+money(sales)),new LinearLayout.LayoutParams(0,78,1));sr.addView(stat("Receivable","₹"+money(due)),new LinearLayout.LayoutParams(0,78,1));stats.addView(sr);body.addView(stats);
        Button sale=btn("＋  NEW SALE",teal);sale.setTextColor(white);sale.setTextSize(17);sale.setOnClickListener(v->sale());body.addView(sale,new LinearLayout.LayoutParams(-1,58));
        TextView add=tv("\nAdd New Customer / Party",15);add.setTextColor(navy);add.setOnClickListener(v->customers());body.addView(add);
    }
    View stat(String a,String b){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.CENTER);TextView x=tv(a,12);x.setTextColor(Color.GRAY);TextView y=tv(b,18);y.setTypeface(Typeface.DEFAULT_BOLD);y.setTextColor(navy);l.addView(x);l.addView(y);return l;}
    String money(double x){return String.format(Locale.getDefault(),"%,.2f",x);}
    void dashboard(){base("DASHBOARD");
        double sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales"),purch=db.scalar("SELECT COALESCE(SUM(total),0) FROM purchases"),exp=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");
        body.addView(kpi("TOTAL SALES","₹"+money(sales)));body.addView(kpi("PURCHASES","₹"+money(purch)));body.addView(kpi("EXPENSES","₹"+money(exp)));body.addView(kpi("NET","₹"+money(sales-purch-exp)));
        Button b=btn("🧾  Create New Invoice",teal);b.setTextColor(white);b.setOnClickListener(v->sale());body.addView(b,new LinearLayout.LayoutParams(-1,56));
    }
    View kpi(String a,String b){LinearLayout c=card();TextView x=tv(a,12);x.setTextColor(Color.GRAY);TextView y=tv(b,25);y.setTypeface(Typeface.DEFAULT_BOLD);y.setTextColor(navy);c.addView(x);c.addView(y);return c;}

    void products(){base("ITEMS");
        LinearLayout q=card();TextView s=tv("⌕  Search for an item or code",15);s.setTextColor(Color.GRAY);q.addView(s);body.addView(q);
        LinearLayout links=card();TextView h=tv("Quick Links",16);h.setTypeface(Typeface.DEFAULT_BOLD);links.addView(h);TextView x=tv("Online Store     Stock Summary     Item Settings     Show All",12);x.setTextColor(teal);links.addView(x);body.addView(links);
        Cursor c=db.products();while(c.moveToNext()){final String name=c.getString(1),unit=c.getString(3);final double stock=c.getDouble(6),sale=c.getDouble(5),purchase=c.getDouble(4);LinearLayout it=card();TextView n=tv(name,17);n.setTypeface(Typeface.DEFAULT_BOLD);n.setTextColor(navy);it.addView(n);TextView info=tv("Sale Price  ₹"+money(sale)+"    Purchase  ₹"+money(purchase)+"\nIn Stock    "+stock+" "+unit,13);it.addView(info);Button more=btn("⋮",white);more.setTextColor(Color.GRAY);it.addView(more,new LinearLayout.LayoutParams(-1,42));body.addView(it);}
        c.close();Button add=btn("＋  ADD NEW ITEM",teal);add.setTextColor(white);add.setTextSize(16);add.setOnClickListener(v->addProductDialog());body.addView(add,new LinearLayout.LayoutParams(-1,56));
    }
    void addProductDialog(){final LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,4,20,4);EditText n=ed("Item Name *"),sku=ed("Item Code"),unit=ed("Unit (pcs, bag, kg)"),pur=ed("Purchase Price"),sale=ed("Sale Price"),stock=ed("Opening Stock");l.addView(n);l.addView(sku);l.addView(unit);l.addView(pur);l.addView(sale);l.addView(stock);new AlertDialog.Builder(this).setTitle("Add New Item").setView(l).setPositiveButton("SAVE",(d,w)->{try{db.addProduct(n.getText().toString(),sku.getText().toString(),unit.getText().toString(),Double.parseDouble(pur.getText().toString()),Double.parseDouble(sale.getText().toString()),Double.parseDouble(stock.getText().toString()));products();}catch(Exception e){Toast.makeText(this,"Enter valid item details",0).show();}}).setNegativeButton("CANCEL",null).show();}

    void sale(){cart.clear();base("SALE");
        LinearLayout type=card();LinearLayout tr=new LinearLayout(this);Button credit=btn("CREDIT",white),cash=btn("CASH",white);credit.setTextColor(teal);cash.setTextColor(teal);tr.addView(credit,new LinearLayout.LayoutParams(0,48,1));tr.addView(cash,new LinearLayout.LayoutParams(0,48,1));type.addView(tr);body.addView(type);
        TextView inv=tv("Invoice No.   INV-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.getDefault()).format(new Date()),14);type.addView(inv);
        LinearLayout customer=card();customer.addView(label("Customer *"));EditText cust=ed("Select Customer / Party");customer.addView(cust);EditText phone=ed("Phone Number");customer.addView(phone);body.addView(customer);
        Button add=btn("＋  ADD ITEMS",teal);add.setTextColor(white);add.setTextSize(16);body.addView(add,new LinearLayout.LayoutParams(-1,54));
        TextView list=tv("No items added",14);body.addView(list);
        LinearLayout totals=card();TextView total=tv("TOTAL AMOUNT   ₹0.00",20);total.setTypeface(Typeface.DEFAULT_BOLD);total.setTextColor(navy);totals.addView(total);EditText discount=ed("Discount");totals.addView(discount);EditText paid=ed("Paid Amount");totals.addView(paid);body.addView(totals);
        LinearLayout actions=new LinearLayout(this);Button saveNew=btn("SAVE & NEW",white),save=btn("SAVE",teal);saveNew.setTextColor(teal);save.setTextColor(white);actions.addView(saveNew,new LinearLayout.LayoutParams(0,56,1));actions.addView(save,new LinearLayout.LayoutParams(0,56,1));body.addView(actions);
        add.setOnClickListener(v->addSaleItemDialog(list,total));save.setOnClickListener(v->saveSale(cust,discount,paid,false));saveNew.setOnClickListener(v->saveSale(cust,discount,paid,true));
    }
    void addSaleItemDialog(TextView list,TextView total){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(16,4,16,4);EditText n=ed("Item Name *"),qty=ed("Quantity"),unit=ed("Unit"),rate=ed("Price / Unit");l.addView(n);l.addView(qty);l.addView(unit);l.addView(rate);new AlertDialog.Builder(this).setTitle("Add Items").setView(l).setPositiveButton("SAVE",(d,w)->{try{double q=Double.parseDouble(qty.getText().toString()),r=Double.parseDouble(rate.getText().toString());cart.add(new Line(0,n.getText().toString(),unit.getText().toString(),q,r));refreshCart(list,total);}catch(Exception e){Toast.makeText(this,"Enter valid item details",0).show();}}).setNeutralButton("SAVE & NEW",null).setNegativeButton("CANCEL",null).show();}
    void refreshCart(TextView list,TextView total){StringBuilder s=new StringBuilder();double sum=0;for(int i=0;i<cart.size();i++){Line x=cart.get(i);s.append(i+1).append(". ").append(x.name).append("\n   ").append(x.qty).append(" ").append(x.unit).append(" × ₹").append(money(x.rate)).append(" = ₹").append(money(x.amount())).append("\n");sum+=x.amount();}list.setText(s.length()==0?"No items added":s.toString());total.setText("TOTAL AMOUNT   ₹"+money(sum));}
    void saveSale(EditText cust,EditText discount,EditText paid,boolean again){if(cart.isEmpty()){Toast.makeText(this,"Add at least one item",0).show();return;}double sub=0;for(Line x:cart)sub+=x.amount();double dis=parse(discount),pay=parse(paid),tot=Math.max(0,sub-dis),bal=Math.max(0,tot-pay);String inv="INV-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.getDefault()).format(new Date());long id=db.createCashSale(inv,cust.getText().toString().trim().isEmpty()?"Cash Customer":cust.getText().toString().trim(),System.currentTimeMillis(),sub,dis,pay,tot,bal);for(Line x:cart)db.addSaleItem(id,x.productId,x.name,x.qty,x.rate);showInvoiceActions(id);if(again){cart.clear();}}
    double parse(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}

    void customers(){base("CUSTOMERS");EditText name=ed("Customer name"),phone=ed("Phone"),address=ed("Address");body.addView(label("Add New Customer / Party"));body.addView(name);body.addView(phone);body.addView(address);Button add=btn("＋ SAVE CUSTOMER",teal);add.setTextColor(white);body.addView(add);add.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty())return;db.addCustomer(name.getText().toString(),phone.getText().toString(),address.getText().toString());Toast.makeText(this,"Customer saved",0).show();customers();});Cursor c=db.customers();while(c.moveToNext()){LinearLayout x=card();x.addView(tv(c.getString(1),16));x.addView(tv(c.getString(2)+"\n"+c.getString(3),13));body.addView(x);}c.close();}
    void purchase(){base("PURCHASE");EditText bill=ed("Bill No."),supplier=ed("Supplier"),item=ed("Product"),qty=ed("Quantity"),rate=ed("Rate"),paid=ed("Paid");body.addView(bill);body.addView(supplier);body.addView(item);body.addView(qty);body.addView(rate);body.addView(paid);Button b=btn("SAVE PURCHASE",teal);b.setTextColor(white);body.addView(b);b.setOnClickListener(v->{try{double q=Double.parseDouble(qty.getText().toString()),r=Double.parseDouble(rate.getText().toString()),p=parse(paid),t=q*r;long id=db.createPurchase(bill.getText().toString(),supplier.getText().toString(),System.currentTimeMillis(),t,p,Math.max(0,t-p));db.addPurchaseItem(id,0,item.getText().toString(),q,r);Toast.makeText(this,"Purchase saved",0).show();}catch(Exception e){Toast.makeText(this,"Fill valid details",0).show();}});}
    void expenses(){base("EXPENSES");EditText t=ed("Expense title"),a=ed("Amount"),n=ed("Note");body.addView(t);body.addView(a);body.addView(n);Button b=btn("SAVE EXPENSE",teal);b.setTextColor(white);body.addView(b);b.setOnClickListener(v->{try{db.addExpense(t.getText().toString(),Double.parseDouble(a.getText().toString()),n.getText().toString());Toast.makeText(this,"Expense saved",0).show();expenses();}catch(Exception e){Toast.makeText(this,"Enter valid amount",0).show();}});}
    void salesHistory(){base("SALES HISTORY");Cursor c=db.sales();while(c.moveToNext()){final long id=c.getLong(0);LinearLayout x=card();x.addView(tv(c.getString(1),16));x.addView(tv(c.getString(3)+"\nTotal ₹"+money(c.getDouble(8))+"  Paid ₹"+money(c.getDouble(7))+"  Balance ₹"+money(c.getDouble(9)),13));Button b=btn("PRINT / PDF / IMAGE",teal);b.setTextColor(white);b.setOnClickListener(v->showInvoiceActions(id));x.addView(b);body.addView(x);}c.close();}
    void reports(){base("REPORTS");double s=db.scalar("SELECT COALESCE(SUM(total),0) FROM sales"),p=db.scalar("SELECT COALESCE(SUM(total),0) FROM purchases"),e=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses"),d=db.scalar("SELECT COALESCE(SUM(balance),0) FROM sales");body.addView(kpi("SALES","₹"+money(s)));body.addView(kpi("RECEIVABLE","₹"+money(d)));body.addView(kpi("PURCHASES","₹"+money(p)));body.addView(kpi("EXPENSES","₹"+money(e)));body.addView(kpi("NET","₹"+money(s-p-e)));}
    void settings(){base("SETTINGS");EditText n=ed("Shop Name"),a=ed("Address"),p=ed("Phone"),g=ed("GSTIN");n.setText(db.setting("shop_name"));a.setText(db.setting("shop_address"));p.setText(db.setting("shop_phone"));g.setText(db.setting("gstin"));body.addView(n);body.addView(a);body.addView(p);body.addView(g);Button b=btn("SAVE SETTINGS",teal);b.setTextColor(white);body.addView(b);b.setOnClickListener(v->{db.setting("shop_name",n.getText().toString());db.setting("shop_address",a.getText().toString());db.setting("shop_phone",p.getText().toString());db.setting("gstin",g.getText().toString());Toast.makeText(this,"Settings saved",0).show();});}
    void menu(){base("MENU");String[][] m={{"🧾 Sales / Invoice","SALE"},{"📋 Sales History","HISTORY"},{"👥 Customers / Ledger","CUSTOMERS"},{"🚚 Purchase","PURCHASE"},{"💸 Expenses","EXPENSES"},{"📊 Reports","REPORTS"},{"⚙ Settings","SETTINGS"}};for(String[] x:m){Button b=btn(x[0],white);b.setTextColor(navy);b.setTextSize(16);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(v->{if(x[1].equals("SALE"))sale();else if(x[1].equals("HISTORY"))salesHistory();else if(x[1].equals("CUSTOMERS"))customers();else if(x[1].equals("PURCHASE"))purchase();else if(x[1].equals("EXPENSES"))expenses();else if(x[1].equals("REPORTS"))reports();else settings();});body.addView(b,new LinearLayout.LayoutParams(-1,58));}}

    void showInvoiceActions(long id){
        new AlertDialog.Builder(this).setTitle("Invoice")
            .setItems(new String[]{"🖨 Print","📄 Save PDF","🖼 Save Image"},(d,w)->{
                if(w==0)printInvoice(id);else if(w==1)savePdf(id);else saveImage(id);
            }).show();
    }

    Bitmap invoiceBitmap(long id){
        Cursor s=db.sale(id);if(!s.moveToFirst()){s.close();return null;}
        String inv=s.getString(1),customer=s.getString(3);double sub=s.getDouble(5),dis=s.getDouble(6),paid=s.getDouble(7),total=s.getDouble(8),bal=s.getDouble(9);
        Bitmap b=Bitmap.createBitmap(1000,1400,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(Color.WHITE);
        Paint p=new Paint(1);p.setColor(Color.BLACK);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(48);c.drawText(db.setting("shop_name"),50,70,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(26);c.drawText(db.setting("shop_address"),50,110,p);c.drawText("Phone: "+db.setting("shop_phone"),50,145,p);
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(34);c.drawText("TAX / RETAIL INVOICE",50,205,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(25);c.drawText(inv,50,245,p);c.drawText("Date: "+new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date(s.getLong(4))),50,280,p);
        c.drawText("Customer: "+customer,50,330,p);
        p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Item",50,400,p);c.drawText("Qty",560,400,p);c.drawText("Rate",690,400,p);c.drawText("Amount",830,400,p);
        Cursor it=db.saleItems(id);int y=450;while(it.moveToNext()){p.setTypeface(Typeface.DEFAULT);c.drawText(it.getString(3),50,y,p);c.drawText(""+it.getDouble(4),560,y,p);c.drawText("₹"+it.getDouble(5),690,y,p);c.drawText("₹"+it.getDouble(6),830,y,p);y+=50;}it.close();
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(30);c.drawText("Subtotal: ₹"+sub,50,y+60,p);c.drawText("Discount: ₹"+dis,50,y+105,p);c.drawText("TOTAL: ₹"+total,50,y+160,p);c.drawText("Paid: ₹"+paid,50,y+205,p);c.drawText("BALANCE: ₹"+bal,50,y+250,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(24);c.drawText("Thank you for your business.",50,y+330,p);s.close();return b;
    }

    void savePdf(long id){
        Bitmap b=invoiceBitmap(id);if(b==null)return;PdfDocument doc=new PdfDocument();PdfDocument.Page pg=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
        pg.getCanvas().drawBitmap(b,null,new Rect(20,20,575,820),new Paint(1));doc.finishPage(pg);
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,"AAYUSH-SALES-"+id+".pdf");pendingDoc=doc;startActivityForResult(i,501);
    }
    PdfDocument pendingDoc;Bitmap pendingImage;
    void saveImage(long id){pendingImage=invoiceBitmap(id);Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("image/png");i.putExtra(Intent.EXTRA_TITLE,"AAYUSH-SALES-"+id+".png");startActivityForResult(i,502);}
    void printInvoice(long id){
        final Bitmap b=invoiceBitmap(id);if(b==null)return;PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        pm.print("AAYUSH SALES Invoice",new PrintDocumentAdapter(){
            public void onLayout(PrintAttributes a,PrintAttributes b,android.os.CancellationSignal c,LayoutResultCallback cb,Bundle x){cb.onLayoutFinished(new PrintDocumentInfo.Builder("invoice.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(),true);}
            public void onWrite(PageRange[] r,android.os.ParcelFileDescriptor fd,android.os.CancellationSignal c,WriteResultCallback cb){try{PdfDocument d=new PdfDocument();PdfDocument.Page pg=d.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());pg.getCanvas().drawBitmap(b,null,new Rect(20,20,575,820),new Paint(1));d.finishPage(pg);d.writeTo(new FileOutputStream(fd.getFileDescriptor()));d.close();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.toString());}}
        },null);
    }

    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data);if(c!=RESULT_OK||data==null)return;
        try(OutputStream o=getContentResolver().openOutputStream(data.getData())){
            if(r==501&&pendingDoc!=null){pendingDoc.writeTo(o);pendingDoc.close();pendingDoc=null;Toast.makeText(this,"PDF saved",0).show();}
            else if(r==502&&pendingImage!=null){pendingImage.compress(Bitmap.CompressFormat.PNG,100,o);pendingImage=null;Toast.makeText(this,"Image saved",0).show();}
        }catch(Exception e){Toast.makeText(this,"Save failed: "+e.getMessage(),1).show();}
    }
}
