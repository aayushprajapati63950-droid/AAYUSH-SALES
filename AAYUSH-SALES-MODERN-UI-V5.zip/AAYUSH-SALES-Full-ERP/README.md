# AAYUSH SALES — Modern Retail ERP UI

Fresh UI based on the user-provided reference screens.

### Home
- Modern Home/Business overview
- Search area
- Quick Links
- Today sales and receivable cards
- New Sale shortcut
- Bottom navigation: HOME / DASHBOARD / ITEMS / MENU

### Items
- Search-style header
- Quick Links
- Item cards with sale price, purchase price and stock
- Add New Item

### Sale
- Credit/Cash selector
- Invoice number
- Customer and phone
- Add Items dialog
- Quantity, unit, price/unit
- Automatic totals, discount and paid amount
- Save & New / Save
- Existing Print / PDF / Image invoice flow

### Navigation
- In-app Back button and Android Back return to AAYUSH SALES Home instead of leaving the app from a module.

### Other modules
Customers, Purchase, Expenses, Reports and Settings remain available from Menu.
